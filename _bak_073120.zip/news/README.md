# ABS-CBN News

## Role
###Frontend Developer for Article page

## Features
### Infinite Scroll, Sticky page, Mobile Responsive

## Technology Used

  - HTML 5
  - jQuery
  - CSS 
  - SASS
