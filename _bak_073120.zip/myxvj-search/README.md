# MYX VJ Search Phase 2

##TEAM

  * **Account Manager:** Karen Tumbali
  * **Digital Strategist:** Asharina Del Rio
  * **Visual Interface Designer:** Daryl Camua
  * **Front-end Developer:** Luis Baptista
  * **Backend Developer:** Tec Teano
  * **Project Manager:** Ej Moran / Debbie Medina


## Site Map Reference
Always check built pages against the site tree. Shade boxes that are finished.
![Site Map](https://bitbucket.org/luiscba/myxvjsearch-v2/downloads/sitemap.png)

## Staging URL
[http://10.0.7.165/MYXVJSEARCH-PHASE-2/staging](http://10.0.7.165/MYXVJSEARCH-PHASE-2/staging)





