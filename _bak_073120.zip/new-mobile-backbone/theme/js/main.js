$(document).ready(function(){

	$("#articles-listItem-view ul")

});