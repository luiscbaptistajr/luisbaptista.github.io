/**!
 * ON THE WINGS OF LOVE
 * ABS-CBN Corporation 2015
 */

(function($) {

    console.log("hello");

})(jQuery);