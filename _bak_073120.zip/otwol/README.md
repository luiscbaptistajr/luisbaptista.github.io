# On the wings of Love

## Role

### Frontend Developer

## Technology Used

  - HTML 5
  - jQuery
  - SASS
  - CSS3
