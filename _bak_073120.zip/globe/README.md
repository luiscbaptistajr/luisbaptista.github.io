# GlOBE [2013]

##Team
**DEV:** LUIS BAPTISTA, JAY GAUTEN

**PM:** LA DACULA

##Staging

