# Sample Wedding Site in Parallax

## Role:
### Frontend Developer, UI Designer

## Technology Used:

  - HTML 5
  - jQuery
  - SASS
  - CSS3
