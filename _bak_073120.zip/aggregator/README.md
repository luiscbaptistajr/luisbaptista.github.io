# Sample website using Dialogue Feed

## Role:

### Frontend Developer

## Features

### JSON Data load from Dialogue Feed <a href="https://www.dialogfeed.com/">https://www.dialogfeed.com/</a>, Mobile Responsive

## Technology Used:


  - HTML 5
  - jQuery
  - AJAX
  - SASS